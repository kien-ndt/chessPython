# chess_tk
python3 tkinter chess

In this project i took the code for the chess game from the book "Tkinter GUI application development" and made it compatible with
Python3.
